import Layout from '../components/template/Layout'

export default function Perfil() {
  return (
    <Layout titulo="Perfil do Usuário" 
      subtitulo="Administre as suas informações de usuário!">
        <h1>Perfil do Usuário</h1>
    </Layout>
  )
}
