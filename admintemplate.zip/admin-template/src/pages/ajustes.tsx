import Layout from '../components/template/Layout'

export default function Ajustes() {
  return (
    <Layout titulo="Ajustes & Configurações" 
      subtitulo="Personalize o sistema por aqui!">
      <h3>Conteúdo!!!!</h3>
    </Layout>
  )
}
