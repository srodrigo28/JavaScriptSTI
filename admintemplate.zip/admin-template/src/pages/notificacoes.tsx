import Layout from '../components/template/Layout'

export default function Notificacoes() {
  return (
    <Layout titulo="Notificações" 
      subtitulo="Aqui você irá gerenciar as suas notificações!">
        <h1>Notificações</h1>
    </Layout>
  )
}
